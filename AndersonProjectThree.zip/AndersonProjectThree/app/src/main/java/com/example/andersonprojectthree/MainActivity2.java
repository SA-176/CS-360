package com.example.andersonprojectthree;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.icu.text.SimpleDateFormat;
import android.icu.util.Calendar;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Scroller;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.Date;
import java.util.Locale;

public class MainActivity2 extends AppCompatActivity {

    //declared variables
    Button buttonAdd;
    Button buttonDelete;
    Button buttonNotify;
    Button buttonUpdate;
    DBEventHelper DB;
    TextView dateView, eventView, descView;
    EditText eventName;
    EditText eventDate;
    EditText eventDesc;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cal_screen);

        //assigning viewTexts
        dateView = findViewById(R.id.viewDate);
        eventView = findViewById(R.id.viewEvent);
        descView = findViewById(R.id.viewDesc);

        //assigning editTexts
        eventName = findViewById(R.id.eventName);
        eventDate = findViewById(R.id.eventDate);
        eventDesc = findViewById(R.id.eventDesc);

        //assigning buttons
        buttonAdd = findViewById(R.id.add_button);
        buttonDelete = findViewById(R.id.clear_button);
        buttonNotify = findViewById(R.id.notify_Button);
        buttonUpdate = findViewById(R.id.update_button);

        //assigning database
        DB = new DBEventHelper(this);

        //code to check current version of build for notification allowance
        //if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            //NotificationChannel channel = new NotificationChannel("My Notification", "My Notification", NotificationManager.IMPORTANCE_DEFAULT);
            //NotificationManager manager = getSystemService(NotificationManager.class);
            //manager.createNotificationChannel(channel);
        //}
        //button for allowing or disallowing notifications
        buttonNotify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String date = eventDate.getText().toString();

                //notification builders which make up the notification and control it
                NotificationCompat.Builder builder = new NotificationCompat.Builder(MainActivity2.this, "My Notification");
                builder.setContentTitle("My Title");
                builder.setContentText("Event Incoming");
                builder.setSmallIcon(R.drawable.ic_launcher_background);
                builder.setAutoCancel(true);

                NotificationManagerCompat managerCompat = NotificationManagerCompat.from(MainActivity2.this);

                if (ActivityCompat.checkSelfPermission(MainActivity2.this, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    Date d = Calendar.getInstance().getTime();
                    SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault());
                    String formattedDate = df.format(d);

                    Boolean dateCheck = DB.checkDate(formattedDate);
                    if (dateCheck == true){

                        builder.setContentText("Event Approaching");
                        //what is supposed to launch the notification
                        managerCompat.notify(1, builder.build());
                    }

                }
            }
        });

        //button add that will add to the db and add to the scroll's textViews
        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //assign strings
                String name = eventName.getText().toString();
                String date = eventDate.getText().toString();
                String description = eventDesc.getText().toString();

                //check to see if event is already logged
                Boolean checkUser = DB.checkEventDate(name, date);
                if (checkUser == false) {
                    //inserting event if not found
                    Boolean insert = DB.insertData(name, date, description);
                    if(insert == true) {
                        Toast.makeText(MainActivity2.this, "added Event", Toast.LENGTH_SHORT).show();
                        //add text to scroll
                        dateView.append("\n" + date);
                        eventView.append("\n" + name);
                        descView.append("\n" + description);
                        //clear strings
                        date = "";
                        name = "";
                        description = "";
                        //clear editText
                        eventName.setText("");
                        eventDate.setText("");
                        eventDesc.setText("");
                    }
                    else{
                        Toast.makeText(MainActivity2.this, "Invalid Event", Toast.LENGTH_SHORT).show();
                    }
                }
                else {
                    Toast.makeText(MainActivity2.this, "Event Exists Already", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //button delete for deleting an event
        buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //assign strings
                String name = eventName.getText().toString();
                String date = eventDate.getText().toString();
                String description = eventDesc.getText().toString();

                Boolean checkUser = DB.checkEventDate(name, date);
                if (checkUser == true) {
                    //inserting event if not found
                    Boolean delete = DB.deleteData(name, date, description);
                }
                else{
                    Toast.makeText(MainActivity2.this, "Invalid Event", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //button for updating an event
        buttonUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //assign strings
                String name = eventName.getText().toString();
                String date = eventDate.getText().toString();
                String description = eventDesc.getText().toString();

                //check to see if event is already logged
                Boolean checkUser = DB.checkEventDate(name, date);
                if (checkUser == false) {
                    //inserting event if not found
                    Boolean insert = DB.updateData(name, date, description);
                    if(insert == true) {
                        Toast.makeText(MainActivity2.this, "updated Event", Toast.LENGTH_SHORT).show();
                        //add text to scroll
                        dateView.append("\n" + date);
                        eventView.append("\n" + name);
                        descView.append("\n" + description);
                        //clear strings
                        date = "";
                        name = "";
                        description = "";
                        //clear editText
                        eventName.setText("");
                        eventDate.setText("");
                        eventDesc.setText("");
                    }
                    else{
                        Toast.makeText(MainActivity2.this, "Invalid Event", Toast.LENGTH_SHORT).show();
                    }
                }
                else {
                    Toast.makeText(MainActivity2.this, "Event Exists Already", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}