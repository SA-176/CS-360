package com.example.andersonprojectthree;

//start of my code for adding notifications


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.NotificationManager;
import android.content.Context;


public class TimerWorker extends AppCompatActivity {

    private final static String CHANNEL_ID_TIMER = "channel_timer";
    private final NotificationManager mNotificationManager;

    public <WorkerParameters> TimerWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super();
        mNotificationManager = (NotificationManager) context.getSystemService(NOTIFICATION_SERVICE);
    }

    public TimerWorker(NotificationManager mNotificationManager) {
        this.mNotificationManager = mNotificationManager;
    }
}
