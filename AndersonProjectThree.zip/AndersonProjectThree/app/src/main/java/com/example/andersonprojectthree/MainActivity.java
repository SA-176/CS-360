package com.example.andersonprojectthree;

import androidx.appcompat.app.AppCompatActivity;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button editButtonNew;
    Button editButtonLogIn;
    EditText editTextUsername;
    EditText editTextPassword;

    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editButtonLogIn = findViewById(R.id.buttonLogIn);
        editButtonNew = findViewById(R.id.buttonNew);
        editTextUsername = findViewById(R.id.editUsername);
        editTextPassword = findViewById(R.id.editPassword);

        //assign database
        DB = new DBHelper(this);

        //button new that adds a new user
        editButtonNew.setOnClickListener (new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                //assign strings
                String user = editTextUsername.getText().toString();
                String pass = editTextPassword.getText().toString();

                //boolean check to see if username is in database
                Boolean checkUser = DB.checkusername(user);
                if (checkUser == false) {
                    //boolean check to make sure insertion is successful
                    Boolean insert = DB.insertData(user, pass);
                    if(insert == true) {
                        Toast.makeText(MainActivity.this, "Welcome", Toast.LENGTH_SHORT).show();
                        //moves to main activity 2 screen
                        Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                        startActivity(intent);
                        MainActivity.this.finish();
                    }
                    else{
                        Toast.makeText(MainActivity.this, "Invalid Registration", Toast.LENGTH_SHORT).show();
                    }
                }
                else {
                    Toast.makeText(MainActivity.this, "Invalid Username", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //Log in button
        editButtonLogIn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                //moves to log in screen
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
            }
        });
    }
}
