package com.example.andersonprojectthree;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    //variables
    Button editButtonLogIn;
    EditText editTextUsername;
    EditText editTextPassword;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //assign variables with elements from screen
        editButtonLogIn = findViewById(R.id.buttonLogIn);
        editTextUsername = findViewById(R.id.editUsername);
        editTextPassword = findViewById(R.id.editPassword);

        //assign database
        DB = new DBHelper(this);

        //button for logging in
        editButtonLogIn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                //assign strings
                String user = editTextUsername.getText().toString();
                String pass = editTextPassword.getText().toString();

                //check to see if username or password are empty
                if(user.equals("") || pass.equals("")) {
                    Toast.makeText(LoginActivity.this, "Not all fields filled out", Toast.LENGTH_SHORT).show();
                }
                else{
                    //boolean check to see if username and password are a match
                    Boolean checkUserPass = DB.checkusernamepassword(user,pass);
                    if(checkUserPass==true){
                        Toast.makeText(LoginActivity.this, "Sign in Successful", Toast.LENGTH_SHORT).show();
                        //moves to main activity 2 screen
                        Intent intent = new Intent(v.getContext(), MainActivity2.class);
                        startActivity(intent);
                    }
                    //else failed log in
                    else{
                        Toast.makeText(LoginActivity.this, "Sign in Failed: Invalid Credentials", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

}
