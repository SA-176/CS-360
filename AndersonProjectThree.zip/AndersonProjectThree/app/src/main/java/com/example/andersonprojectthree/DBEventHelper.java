package com.example.andersonprojectthree;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBEventHelper extends SQLiteOpenHelper {
    //create database and name it
    public static final String DBName = "Event.db";
    public DBEventHelper(Context context) {super(context, "Event.db", null, 1);}

    @Override
    public void onCreate(SQLiteDatabase myDB) {
        myDB.execSQL("create Table events(event TEXT primary key, date TEXT, description TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase myDB, int i, int i1) {

    }

    //inserts data into the database
    public Boolean insertData(String event, String date, String description) {
        SQLiteDatabase myDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Event", event);
        contentValues.put("Date", date);
        contentValues.put("Description", description);
        long result = myDB.insert("events", null, contentValues);
        if(result == -1){
            return false;
        }
        else {
            return true;
        }
    }

    public Boolean deleteData(String event, String date, String description) {
        SQLiteDatabase myDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Event", event);
        contentValues.put("Date", date);
        contentValues.put("Description", description);
        long result = myDB.delete("Event" , null, new String[] {event});
        if(result == -1){
            return false;
        }
        else {
            return true;
        }
    }

    //used to update the data in database (unfinished)
    public boolean updateData(String event,String date, String desc){
        SQLiteDatabase myDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Event", event);
        contentValues.put("Date", date);
        contentValues.put("Description", desc);

        return false;
    }
    //used to check the event and date against the database
    public Boolean checkEventDate(String event, String date){
        SQLiteDatabase myDB = this.getWritableDatabase();
        Cursor cursor = myDB.rawQuery("Select * from events where event = ? and date = ?", new String[] {event, date});
        if(cursor.getCount() > 0){
            return true;
        }
        else{
            return false;
        }
    }

    public Boolean checkDate(String date){
        SQLiteDatabase myDB = this.getWritableDatabase();
        Cursor cursor = myDB.rawQuery("Select * from events where event = ? and date = ?", new String[] {date});
        if(cursor.getCount() > 0){
            return true;
        }
        else{
            return false;
        }
    }

}
