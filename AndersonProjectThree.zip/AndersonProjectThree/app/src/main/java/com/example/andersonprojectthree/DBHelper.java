package com.example.andersonprojectthree;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {
    //create database and name it
    public static final String DBName = "Login.db";
    public DBHelper( Context context) {super(context, "Login.db", null, 1);}

    @Override
    public void onCreate(SQLiteDatabase myDB) {
        myDB.execSQL("create TAble users(username TEXT primary key, password TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase myDB, int i, int i1) {
        myDB.execSQL("drop Table if exists users");

    }

    //inserts data into the database
    public Boolean insertData(String username, String password) {
        SQLiteDatabase myDB = this.getWritableDatabase();
        //assign values passed to insertData into contentValues
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", username);
        contentValues.put("password", password);
        //long check to see if data was inserted
        long result = myDB.insert("users", null, contentValues);
        if(result == -1){
            return false;
        }
        else {
            return true;
        }
    }

    //function to checking the username against existing usernames
    public Boolean checkusername(String username){
        SQLiteDatabase myDB = this.getWritableDatabase();
        //if cursor is greater that 0 it means that the username is already in use
        Cursor cursor = myDB.rawQuery("Select * from users where username = ?", new String[] {username});
        if (cursor.getCount() > 0){
            return true;
        }
        else{
            return false;
        }
    }

    //function to check both username and password
    public Boolean checkusernamepassword(String username, String password){
        SQLiteDatabase myDB = this.getWritableDatabase();
        //if cursor is greater than 0 it means that the username and password has been found in the database
        Cursor cursor = myDB.rawQuery("Select * from users where username = ? and password = ?", new String[] {username, password});
        if(cursor.getCount() > 0){
            return true;
        }
        else{
            return false;
        }
    }
}
